package com.ibm.training.users;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

	@Autowired
	UserService service;

	// getting a user name
//	@RequestMapping("/users/{uid}")
//	String getUser(@PathVariable("uid") int id) {
//		return service.getUser(id);
//	}

	// getting users
	@RequestMapping("/users")
	List<User> getUsers() {
		return service.getUsers();
	}

	// getting details of user by id
	@RequestMapping("/users/{uid}")
	User getUser(@PathVariable("uid") int id) {
		return service.getUser(id);
	}

	// add a new user
	@RequestMapping(method = RequestMethod.POST, value = "/users")
	void addUser(@RequestBody User user) {
		service.addUser(user);
	}

	// update a user by name
	@RequestMapping(method = RequestMethod.PUT, value = "/users/{name}")
	void updateUser(@RequestBody User user, @PathVariable String name) {
		service.updateUser(user, name);
	}

	// delete a user by id
	@RequestMapping(method = RequestMethod.DELETE, value = "/users/{id}")
	void deleteUser(@PathVariable Integer id) {
		service.deleteUser(id);
	}

}
