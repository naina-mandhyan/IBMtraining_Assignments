package com.ibm.training.users;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	
	@Autowired
	UserDao dao;
	
//	String getUser(int id) {
//		return dao.getUser(id);
//	}

	public List<User> getUsers() {
		return dao.getUsers();
	}

	public User getUser(int id) {
		return dao.getUser(id);
	}

	public void addUser(User user) {
		 dao.addUser(user);
		
	}

	public void updateUser(User user, String name) {
		dao.updateUser(user,name);
		
	}

	public void deleteUser(Integer id) {
		dao.deleteUser(id);
		
	}

}
