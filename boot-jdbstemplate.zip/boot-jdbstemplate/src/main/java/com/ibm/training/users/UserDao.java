package com.ibm.training.users;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class UserDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	User user;

//	public String getUser(int id) {
//		
//		String sql = "select Name from firsttable where PhoneNo=?";
//		
//		return jdbcTemplate.queryForObject(sql, new Object[] {id}, String.class);
//	}

	public List<User> getUsers() {
		String sql = "select * from firsttable ";
		return jdbcTemplate.query(sql,new UserMapper());
	}
	
	
	public User getUser(int id) {
		String sql = "select * from firsttable where UserId=?";
		return jdbcTemplate.queryForObject(sql, new Object[] {id}, new UserMapper());
		
	}


	public void addUser(User user) {
		String sql = "insert into firsttable values(?,?,?)";
		jdbcTemplate.update(sql, new Object[] {user.getUserName(),user.getUserId(),user.getUserAddress()});
		
	}


	public void updateUser(User user, String name) {
		String sql ="update firsttable set UserId = ? where Name= ?";
		jdbcTemplate.update(sql,new Object[] {user.getUserId(),name});
		
	}


	public void deleteUser(Integer id) {
		String sql ="delete from firsttable where UserId= ?";
		jdbcTemplate.update(sql,new Object[] {id});
		
	}
	
	class UserMapper implements RowMapper<User>{

		public User mapRow(ResultSet rs, int rowNum) throws SQLException {
			user = new User();
			user.setUserId(rs.getInt("UserId"));
			user.setUserName(rs.getString("Name"));
			user.setUserAddress(rs.getString("City"));
			return user;
		}
		
	}



}
