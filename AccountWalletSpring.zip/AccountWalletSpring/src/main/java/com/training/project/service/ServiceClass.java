package com.training.project.service;

import com.training.project.dao.DaoClass;

public class ServiceClass {
	DaoClass dao;

	public DaoClass getDao() {
		return dao;
	}

	public void setDao(DaoClass dao) {
		this.dao = dao;
	}
	
	public String showDetails(Integer accno) {
		return(dao.showDetails(accno));
	}

	public String addBalance(Integer accno, int add) {
		return(dao.addBalance(accno,add));
		
	}
	
	public String subBalance(Integer accno, int sub) {
		return(dao.subBalance(accno,sub));
		
	}

	public void createAcc(String name, String mob) {
		dao.createAcc(name,mob);
		
	}

}
