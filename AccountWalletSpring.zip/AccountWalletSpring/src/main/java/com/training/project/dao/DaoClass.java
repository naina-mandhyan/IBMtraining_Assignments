package com.training.project.dao;

import java.util.HashMap;
import java.util.Map;

import com.training.project.bean.UserClass;

public class DaoClass {
	
	public Map<Integer,Object> users;

	public Map<Integer, Object> getUsers() {
		return users;
	}

	public void setUsers(Map<Integer, Object> users) {
		this.users = users;
	}
	
	public String showDetails(Integer accno) {
			for (Map.Entry val : users.entrySet()) {
				if(val.getKey().equals(accno)) {
					return("Account No: "+val.getKey()+" "+val.getValue());
				}
			}
		return null;
	}

	public String addBalance(Integer accno, int add) {
		for (Map.Entry val : users.entrySet()) {
			if(val.getKey().equals(accno)) {
				((UserClass) val.getValue()).setBalance(((UserClass) val.getValue()).getBalance()+add);
				return("Updated Balance: "+((UserClass) val.getValue()).getBalance());
			}
		}
		return null;
	}
	
	public String subBalance(Integer accno, int sub) {
		for (Map.Entry val : users.entrySet()) {
			if(val.getKey().equals(accno)) {
				((UserClass) val.getValue()).setBalance(((UserClass) val.getValue()).getBalance()-sub);
				return("Updated Balance: "+((UserClass) val.getValue()).getBalance());
			}
		}
		return null;
	}

	public void createAcc(String name, String mob) {
		Integer acc = (int)(Math.random()*9000) + 1000;
		UserClass user= new UserClass();
		user.setUserName(name);
		user.setPhoneNo(mob);
		user.setBalance(1000);
		this.users.put(acc, user);
		System.out.println(acc);
		System.out.println(this.showDetails(acc));
		
	}

}
