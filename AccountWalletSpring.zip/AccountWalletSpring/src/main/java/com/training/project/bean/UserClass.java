package com.training.project.bean;

public class UserClass {
	//private Integer accountNo;
	private String userName;
	private String phoneNo;
	private Integer balance;
	
//	public UserClass(String userName, String phoneNo, Integer balance) {
//		//this.accountNo = accountNo;
//		this.userName = userName;
//		this.phoneNo = phoneNo;
//		this.balance = balance;
//	}
	
	
//	  public void setAccountNo(Integer accountNo) 
//	  { 
//		  this.accountNo = accountNo; 
//	  }
	  
	  public void setUserName(String userName) 
	  { 
		  this.userName = userName; 
	  }
	  
	  public void setPhoneNo(String phoneNo) 
	  { 
		  this.phoneNo = phoneNo; 
	  }
	  
	  public void setBalance(Integer balance) 
	  { 
		  this.balance = balance; 
	  }
	 
//	  public Integer getAccountNo() { 
//		  return accountNo; 
//	  } 
//	  
	  public String getUserName() {
		  return userName; 
	  } 
	  
	  public String getPhoneNo() { 
		  return phoneNo;
	  } 
	  
	  public Integer getBalance() { 
		  return balance; 
	  }
	  
	  public String toString() {
		 return("\nName: "+userName+ "\nMobile No: "+ phoneNo+"\nAccount Balance: "+ balance);
	  }
	 
	
}
