package com.training.project.ui;

import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.training.project.bean.UserClass;
import com.training.project.dao.DaoClass;
import com.training.project.service.ServiceClass;

public class App 
{
    public static void main( String[] args )
    {
    	
    	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("walletContext.xml");
    	DaoClass d = context.getBean("daoC",DaoClass.class);
    	UserClass user = context.getBean("userC",UserClass.class);
    	
    	
    	Scanner scan = new Scanner(System.in);
    	
    	ServiceClass serv = context.getBean("servC",ServiceClass.class);
    	
    	System.out.println("1.Create an account\n2.Already registered?");
    	int option= scan.nextInt();
    	scan.nextLine();
    	
    	if(option==1) {
    	
    	System.out.println("enter your name: ");
    	String name=scan.nextLine();
    	System.out.println("enter your mobile no: ");
    	String mob=scan.nextLine();
    	
    	serv.createAcc(name,mob);
    	
    	}
    	
    	else if(option==2) {
    	
    	System.out.println("Enter your account no: to get all details..");
    	int choice = 0;
    	String result="";
    	Integer accno = scan.nextInt(); 
    	scan.nextLine();
    	result = serv.showDetails(accno);
    	System.out.println(result);
    	do {
    	System.out.println("1. Deposit");
    	System.out.println("2. Withdraw");
    	System.out.println("3. Exit");
    	choice= scan.nextInt();
    	scan.nextLine();
    	switch(choice) {
    	case 1: 
    		System.out.println("Enter amount to add");
    		int add = scan.nextInt();
        	scan.nextLine();
    		result = serv.addBalance(accno,add);
    		System.out.println(result);
    		break;
    	case 2: 
    		System.out.println("Enter amount to withdraw");
    		int sub = scan.nextInt();
        	scan.nextLine();
    		result = serv.subBalance(accno,sub);
    		System.out.println(result);
    		break;
    	case 3:
    		break;
    	}
    	}while(choice != 3);
    	
    	}
    }
}
