package com.ibm.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Fetch2 {
	Connection dbCon;
	PreparedStatement state;

	public Fetch2() {
		try {
			// load driver
			Class.forName("com.mysql.jdbc.Driver");
			// establishing connection
			this.dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/project_db?useUnicode=true&u"
					+ "seJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
					"root","");
			// check for connection
			if (this.dbCon == null)
				System.out.println("connetcion not established");
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Some error occured: " + e);
		}
	}
	
	public ResultSet fetchDetails() {
		String fetchQry = "select * from project_information";
				try {
					PreparedStatement state = this.dbCon.prepareStatement(fetchQry);
					ResultSet rs = state.executeQuery();
					return rs;
				}
				catch (SQLException e) {
					System.out.println("Some error while fetching" + e);
				}
			return null;	
	}

}
