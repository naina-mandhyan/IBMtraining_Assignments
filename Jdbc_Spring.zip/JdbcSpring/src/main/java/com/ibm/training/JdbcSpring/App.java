package com.ibm.training.JdbcSpring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("appContext.xml");

        NamedParamDemo dao = (NamedParamDemo) context.getBean("namedParamDemo");
        
        
        
        dao.addUser(7,"Money","Help");
        
        
        System.out.println(dao.getUserName(7, "Help"));
        
        
        
        
        
//      JdbcDao dao = (JdbcDao) context.getBean("jdbcDao");
//        dao.addNewUser(new User("new","new",10));
//        User u = new User();
//        u.setJob("job1");
//        u.setEmpId(10);
//        dao.updateUser(u);
        
        /*dao.deleteUser(u);
        
        for(User user: dao.getUsers()) {
        	System.out.print(" Id: "+user.getEmpId());
        	System.out.print(" Name: "+user.getEmpName());
        	System.out.println(" Role: "+user.getJob());
        }*/
    }
    
}
