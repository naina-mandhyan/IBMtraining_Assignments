package com.ibm.training.JdbcSpring;

public class User {
	
	String EmpName,Job;
	Integer EmpId;
	
	
	public User(String empName, String job, Integer empId) {
		
		EmpName = empName;
		Job = job;
		EmpId = empId;
	}
	public User() {
		// TODO Auto-generated constructor stub
	}
	public String getEmpName() {
		return EmpName;
	}
	public String getJob() {
		return Job;
	}
	public Integer getEmpId() {
		return EmpId;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public void setJob(String job) {
		Job = job;
	}
	public void setEmpId(Integer empId) {
		EmpId = empId;
	}
	
	

}
