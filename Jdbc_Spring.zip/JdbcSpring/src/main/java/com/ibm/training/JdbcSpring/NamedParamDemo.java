package com.ibm.training.JdbcSpring;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

@Component
public class NamedParamDemo {
	
	DataSource ds;
	
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public DataSource getDs() {
		return ds;
	}

	@Autowired
	public void setDs(DataSource ds) {
		this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(ds);
	}
	
	String getUserName(int empId, String empJob) {
		String sql = "select EmpName from employee where EmpNo = :uId and Job = :uJob";
		
		SqlParameterSource paramSource = new MapSqlParameterSource("uId", empId)
												.addValue("uJob", empJob);
		
		return namedParameterJdbcTemplate.queryForObject(sql, paramSource, String.class);
	}

	public void addUser(int empId, String empName, String empJob) {
		String sql ="insert into employee values(:uId,:uName,:uJob)";
		
		SqlParameterSource paramSource = new MapSqlParameterSource("uId", empId).addValue("uName", empName)
				.addValue("uJob", empJob);
		
		namedParameterJdbcTemplate.update(sql,paramSource);
	}
			
	
	

}
