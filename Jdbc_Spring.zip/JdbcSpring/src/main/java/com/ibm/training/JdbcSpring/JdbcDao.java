package com.ibm.training.JdbcSpring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class JdbcDao {
	
	
	DataSource ds;
	
	JdbcTemplate jdbcTemplate;

	public DataSource getDs() {
		return ds;
	}

	@Autowired
	public void setDs(DataSource ds) {
		this.jdbcTemplate = new JdbcTemplate(ds);
	}
	
	int getUserCount() {
		String sql="select count(EmpName) from employee";
		//jdbcTemplate.setDataSource(this.ds);
		return jdbcTemplate.queryForObject(sql, Integer.class);
	}
	
	 List<User> getUsers() { 
		  String sql = "select * from employee"; 
		  return jdbcTemplate.query(sql,new UserMapper()); 
	}
	
	
	void addNewUser(User user) {
		String sql ="insert into employee values(?,?,?)";
		jdbcTemplate.update(sql,new Object[] {
			user.getEmpId(),
			user.getEmpName(),
			user.getJob()
		});
	}
	
	void deleteUser(User user) {
		String sql ="delete from employee where EmpNo = ?";
		jdbcTemplate.update(sql,new Object[] {
			user.getEmpId()
		});
	}
	
	void updateUser(User user) {
		String sql ="update employee set Job = ? where EmpNo = ?";
		jdbcTemplate.update(sql,new Object[] {
			user.getJob(),
			user.getEmpId()
		});
	}
	 
	class UserMapper implements RowMapper<User>{

		public User mapRow(ResultSet rs, int rowNum) throws SQLException {
			User user = new User();
			user.setEmpId(rs.getInt("EmpNo"));
			user.setEmpName(rs.getString("EmpName"));
			user.setJob(rs.getString("Job"));
			return user;
		}
		
	}
	
	
	

}
