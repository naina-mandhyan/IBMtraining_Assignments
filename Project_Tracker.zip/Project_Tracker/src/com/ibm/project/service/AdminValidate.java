package com.ibm.project.service;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ibm.project.dao.FetchA;
import com.ibm.project.dao.Fetch_login_details;

@WebServlet("/admin")
public class AdminValidate extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");
		 HttpSession session = request.getSession();
		 
		 
		 if(session.getAttribute("loggedId")!=null)
			 response.sendRedirect("dashboard.jsp");
		 else if(session.getAttribute("loggedId")==null && request.getParameter("name")==null )
			 response.sendRedirect("admin.jsp");
		 else
		 {
			//response.getWriter().println("Sorry User does not exist,Pls Signup First.........");
			
			String un=request.getParameter("name");
			//session.setAttribute("user", un);
			String pass=request.getParameter("password");
		//	response.getWriter().println("un: " + un + ", pass:" + pass );
			RequestDispatcher dispatcher=request.getRequestDispatcher("dashboard.jsp");
			RequestDispatcher dispatcher1=request.getRequestDispatcher("admin.jsp");
			if(Fetch_login_details.validate_Admin(un, pass))
			{
				session.setAttribute("loggedId", un);
				ResultSet rs = FetchA.fetchUserDetails(un);
				try {
					rs.next();
					session.setAttribute("userName", rs.getString(1));
					// response.getWriter().println("---------------"); 
				} catch (SQLException e) {
					
					response.getWriter().println("SQE: " + e);
				}
				
				dispatcher.forward(request, response);
			}
			else
			{
				response.getWriter().println("Sorry User does not exist,Pls Signup First.........");
			   // dispatcher1.include(request,response);   
			}
	}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
