package com.ibm.mra.junitTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.ibm.mra.service.AccountServiceImpl;
import com.ibm.mra.service.MyMismatchException;

class unitTestClass {
	
	AccountServiceImpl service;
	
	@BeforeEach
	void createObject() {
		service = new AccountServiceImpl();
	}

	@ParameterizedTest
	@ValueSource(strings = {"98399","2118456789"})
	void checkMobNo(String mob) throws MyMismatchException {
		String expected = "pass";
		assertEquals(expected, service.validateMobileNo(mob), "Mob no should contain numbers only and have 10 digits");
		
	}
}
