package com.ibm.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.ibm.mra.bean.Account;

public class AccountDaoImpl implements AccountDao {
	
	private HashMap<String,Account> accountEntry = new HashMap<>();
	
		{
		
		accountEntry.put("9999999999", new Account("Prepaid", "Vaishali", 200));
		accountEntry.put("9823920123", new Account("Prepaid", "Megha", 453));
		accountEntry.put("9932012345", new Account("Prepaid", "Vikas", 631));
		accountEntry.put("9010210131", new Account("Prepaid", "Anju", 521));
		accountEntry.put("9010210131", new Account("Prepaid", "Tushar", 632));
		}

	public boolean checkMobileNo(String mobileNo) {
		for (Map.Entry val : accountEntry.entrySet()) {
			if(mobileNo.equals(val.getKey()))
				return true;
		}
		return false;
	}

	public Double getAccountBal(String mobileNo) {
		for (Map.Entry val : accountEntry.entrySet()) {
			if(mobileNo.equals(val.getKey())) {
				Account user = (Account)val.getValue();
				return(user.getAccountBalance());
			}
		}
		return null;
	}
	
	public Account getAccountDetails(String mobileNo) {
		for (Map.Entry val : accountEntry.entrySet()) {
			if(mobileNo.equals(val.getKey())) {
				Account user = (Account)val.getValue();
				return user;
			}
	}
		return null;
	}

	public void setAccountBal(String mobileNo, Double amount) {
		for (Map.Entry val : accountEntry.entrySet()) {
			if(mobileNo.equals(val.getKey())) {
				Account user = (Account)val.getValue();
				user.setAccountBalance(user.getAccountBalance() + amount);
			}
		}
		
	}


}
