package com.ibm.mra.service;

import com.ibm.mra.bean.Account;

public interface AccountService {
	public void setAccountBal(String mobileNo, Double amount);
	public Account getAccountDetails(String mobileNo);
}
