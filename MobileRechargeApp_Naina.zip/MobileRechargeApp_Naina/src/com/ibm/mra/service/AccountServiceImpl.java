package com.ibm.mra.service;

import com.ibm.mra.bean.Account;
import com.ibm.mra.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
	
	AccountDaoImpl dao = new AccountDaoImpl();

	public String validateMobileNo(String mobileNo) throws MyMismatchException {
		if(mobileNo.matches("[a-zA-z]+"))
			throw new MyMismatchException("mobile no should be in digits only..enter again");
		if(!mobileNo.matches("[0-9]{10}"))
			return "Mobile number should be of 10 digits..enter again";
		if(!dao.checkMobileNo(mobileNo))
			return "Mobile number not registered with account..enter again";
		return "pass";
		}

	public Double getAccountBal(String mobileNo) {
		return(dao.getAccountBal(mobileNo));
	}

	public void setAccountBal(String mobileNo, Double amount) {
		dao.setAccountBal(mobileNo, amount);
		
	}

	public Account getAccountDetails(String mobileNo) {
		return(dao.getAccountDetails(mobileNo));
	}

}
