package com.ibm.mra.service;

public class MyMismatchException extends Exception {
	public MyMismatchException(String str) {
		super(str);
	}
	
}