package com.ibm.mra.ui;

import com.ibm.mra.service.MyMismatchException;

import java.util.Scanner;

import com.ibm.mra.bean.Account;
import com.ibm.mra.service.AccountServiceImpl;

public class MainUi {

	public static void main(String[] args) {
		
		AccountServiceImpl service = new AccountServiceImpl();
		
		Scanner scan = new Scanner(System.in);
		int choice;
		String mobileNo = "";
		Double balance = 0.0;
		Double amount = 0.0;
		
		do {
			String msg;
		System.out.println("Mobile recharge application services:");
		System.out.println("1.Account Balance enquiry \n2.Recharge Account \n3.Exit");
		choice = scan.nextInt();
		scan.nextLine();
		System.out.println("Enter the mobile number");
		while(true) {
			while(true) {
			try {
			mobileNo = scan.nextLine();
			msg = service.validateMobileNo(mobileNo);
			break;
			}
			catch(MyMismatchException e) {
				System.out.println(e);
			}
			}
			if(msg.equalsIgnoreCase("pass"))
				break;
			System.out.println(msg);
		}
		if(choice == 1) {
			
			balance = service.getAccountBal(mobileNo);
			System.out.println("Your current account balance is : "+ balance);
			
		}
		
		else if(choice == 2) {
			
			System.out.println("Enter the Recharge Amount");
			amount = scan.nextDouble();
			scan.nextLine();
			service.setAccountBal(mobileNo, amount);
			System.out.println("Account Recharged Successfully");
			Account user = service.getAccountDetails(mobileNo);
			System.out.println(user.getCustomerName() + ", Your Current Account Balance is " + user.getAccountBalance());
		}
		
		else
			System.out.println("Wrong Choice Entered");
		
		}while(choice != 3);

	}

}
