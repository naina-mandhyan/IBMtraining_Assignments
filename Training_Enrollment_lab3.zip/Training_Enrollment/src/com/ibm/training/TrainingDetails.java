package com.ibm.training;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/log")
public class TrainingDetails extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().println("<table><tr><th style='padding:5px'>ID</th><th style='padding:5px'>"
				+ "CourseName</th><th style='padding:5px'>AvailableSeats</th></tr>");
		ResultSet rs = new DaoClass().fetchDetails();
		
		try {
			while(rs.next()) {
				if(rs.getInt("availableSeats") > 0)
				response.getWriter().println("<tr><td style='padding:5px'>" + rs.getInt("trainingId") + "</td><td style='padding:5px'>"
				+ rs.getString("trainingName") + "</td><td style='padding:5px'>" 
						+ rs.getInt("availableSeats") + "</td><td style='padding:5px'><a href=update?id="+rs.getInt("trainingId")+">Enroll now</a></td></tr>");
				else
					response.getWriter().println("<tr><td style='padding:5px'>" + rs.getInt("trainingId") + "</td><td style='padding:5px'>"
							+ rs.getString("trainingName") + "</td><td style='padding:5px'>" 
									+ rs.getInt("availableSeats") + "</td></tr>");
					
			}
			} catch (SQLException e) {
			System.out.println("some error..");
		}
	}

}
