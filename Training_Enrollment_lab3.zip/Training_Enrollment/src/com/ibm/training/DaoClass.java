package com.ibm.training;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DaoClass {
	Connection dbCon;
	PreparedStatement state;

	DaoClass() {
		try {
			// load driver
			Class.forName("com.mysql.jdbc.Driver");
			// establishing connection
			this.dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/fsdtrainingibm", "root", "");
			// check for connection
			if (this.dbCon == null)
				System.out.println("connetcion not established");
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Some error occured: " + e);
		}
	}
	
	public ResultSet fetchDetails() {
		String fetchQry = "select * from training";
				try {
					PreparedStatement state = this.dbCon.prepareStatement(fetchQry);
					ResultSet rs = state.executeQuery();
					return rs;
				}
				catch (SQLException e) {
					System.out.println("Some error while fetching" + e);
				}
			return null;	
	}

	public void updateDetails(int id) {
		String updateQry = "update training set availableSeats = availableSeats-1 where trainingId = ?";
		try {
			PreparedStatement state = this.dbCon.prepareStatement(updateQry);
			state.setInt(1, id);
			state.executeUpdate();
			
		} catch (SQLException e) {
			System.out.println("Some error while updating" + e);
		}
	}
}