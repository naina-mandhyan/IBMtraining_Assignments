package com.ibm.project.service;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ibm.project.dao.FetchA;
import com.ibm.project.dao.Fetch_login_details;
@WebServlet("/navigate")
public class Project_Navigate extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");
		 HttpSession session = request.getSession();
			String un=request.getParameter("userid");
			//session.setAttribute("user", un);
			String pass=request.getParameter("password");
			RequestDispatcher dispatcher=request.getRequestDispatcher("PCE.html");
			RequestDispatcher dispatcher1=request.getRequestDispatcher("login.jsp");
			if(Fetch_login_details.validate_User(un,pass))
			{
				session.setAttribute("loggedId", un);
				ResultSet rs = FetchA.fetchUserDetails(un);
				try {
					rs.next();
					//session.setAttribute("userName", rs.getString(1));
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
				dispatcher.include(request, response);
			}
			else
			{
				response.getWriter().println("Sorry User does not exist,Pls Signup First.........");
			    dispatcher1.include(request,response);   
			}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
