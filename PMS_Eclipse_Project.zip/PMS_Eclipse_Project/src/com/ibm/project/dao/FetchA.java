package com.ibm.project.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class FetchA {
	
		static Connection con;
		
	static 	int n;
		static ResultSet rs;
		public static ResultSet fetchProjects() {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			     con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project_db?useUnicode=true&u"
							+ "seJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
							"root","");
				String sql="select * from project_information";
				 Statement stmt=con.createStatement();
				 rs=stmt.executeQuery(sql);
				} catch (SQLException | ClassNotFoundException e) {
				e.printStackTrace();
			}
	     return rs;
		}
		
		public static ResultSet fetchUserDetails(String loggedId) {
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
			     con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project_db?useUnicode=true&u"
							+ "seJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
							"root","");
				String fetchQry = "select * from employee_signup where Emp_id = '"+loggedId+"'";
				Statement state = con.createStatement();
				rs = state.executeQuery(fetchQry);
			} catch (SQLException | ClassNotFoundException e) {
				System.out.println("Some error while fetching" + e);
			}
			return rs;
		}

		
		static 	public ResultSet details(int a)
		{
			System.out.println(a);
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
			     con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project_db?useUnicode=true&u"
							+ "seJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
							"root","");
				String sql="select * from project_information where Task_ID='"+a+"' ";
				 Statement stmt=con.createStatement();
				 //stmt.setInt(1, a);
				 rs=stmt.executeQuery(sql);
				} catch (SQLException | ClassNotFoundException e) {
				e.printStackTrace();
			}
	     return rs;
		}
		
		
	}


